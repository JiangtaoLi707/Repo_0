import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris   # 调用数据
import random
import math
import time
import numpy as np
from sklearn import metrics



iris = load_iris()  # 导入sklearn自带的鸢尾花数据集
df = pd.DataFrame(iris.data, columns=iris.feature_names)
# print(df)

df_list = df.values.tolist()

cnt = 0              # 打标签 （加入监督）
for i in df_list:
    i.append(cnt)
    cnt += 1


''' Dataset'''
random.seed(7)
random.shuffle(df_list)
print(df_list)

''' draw original pic'''
feature_original = [[], [], [], []]
for item in df_list:
    feature_original[0].append(item[0])
    feature_original[1].append(item[1])
    feature_original[2].append(item[2])
    feature_original[3].append(item[3])


'''K-means algorithm'''

cluster_center = random.sample(df_list, 3)    # 第一次 从数据集中随机取3个聚类中心
print(cluster_center)

def cal_Euclidean_dist(x,y):
    return ((x[0]-y[0])**2 + (x[1]-y[1])**2 + (x[2]-y[2])**2 + (x[3]-y[3])**2)**0.5


def get_new_center(l0, l1, l2):
    center = []
    for l in l0, l1, l2:
        l_temp = [0, 0, 0, 0]
        for i in l:
            l_temp = [x + y for x, y in zip(l_temp, i[:4])]     # 把一个类里的所有feature都加起来
        center_temp = [item/len(l) for item in l_temp]          # 求平均值，得到新的聚类中心
        center.append(center_temp)
    return center


cnt = 0
loop_cnt = 0
curr_lb_cluster = []

lb_actual = ['Setosa']*50 + ['Versicolour']*50 + ['Virginica']*50
lb_cluster = [0]*150


while True:
    previous_lb_cluster = lb_cluster
    lb_cluster = [0]*150
    print(f'============ iteration:{loop_cnt} ============')
    cluster_0, cluster_1, cluster_2 = [], [], []
    for item in df_list:
        # print(item)
        dist_0 = cal_Euclidean_dist(item, cluster_center[0])
        dist_1 = cal_Euclidean_dist(item, cluster_center[1])
        dist_2 = cal_Euclidean_dist(item, cluster_center[2])
        # print(f'dist_0:{dist_0}, dist_1:{dist_1}, dist_2:{dist_2}')
        if dist_0 < dist_1 and dist_0 < dist_2:
            cluster_0.append(item)
            lb_cluster[item[4]] = 'A'
        elif dist_1 < dist_0 and dist_1 < dist_2:
            cluster_1.append(item)
            lb_cluster[item[4]] = 'B'
        elif dist_2 < dist_0 and dist_2 < dist_1:
            cluster_2.append(item)
            lb_cluster[item[4]] = 'C'
    cluster_center = get_new_center(cluster_0, cluster_1, cluster_2)
    print(f'cluster_center:{cluster_center}')
    time.sleep(0.2)
    cluster_0_idx, cluster_1_idx, cluster_2_idx = [], [], []
    for i in cluster_0:
        cluster_0_idx.append(i[4])
    for i in cluster_1:
        cluster_1_idx.append(i[4])
    for i in cluster_2:
        cluster_2_idx.append(i[4])
    cluster_0_idx.sort()
    cluster_1_idx.sort()
    cluster_2_idx.sort()
    print(f'cluster_0:({len(cluster_0_idx)}) {cluster_0_idx}')
    print(f'cluster_1:({len(cluster_1_idx)}) {cluster_1_idx}')
    print(f'cluster_2:({len(cluster_2_idx)}) {cluster_2_idx}')
    c0_feature = [[], [], [], []]
    c1_feature = [[], [], [], []]
    c2_feature = [[], [], [], []]
    c3_feature = [[], [], [], []]
    for i in cluster_0:
        c0_feature[0].append(i[0])
        c0_feature[1].append(i[1])
        c0_feature[2].append(i[2])
        c0_feature[3].append(i[3])
    for i in cluster_1:
        c1_feature[0].append(i[0])
        c1_feature[1].append(i[1])
        c1_feature[2].append(i[2])
        c1_feature[3].append(i[3])
    for i in cluster_2:
        c2_feature[0].append(i[0])
        c2_feature[1].append(i[1])
        c2_feature[2].append(i[2])
        c2_feature[3].append(i[3])




    if previous_lb_cluster == lb_cluster:

        # def p(l):
        #     print('{:<10}{:<10}{:<10}{:<10}{:<10}{:<10}{:<10}{:<10}{:<10}{:<10}'.format(l[0], l[1], l[2], l[3], l[4]), l[5], l[6], l[7], l[8], l[9])
        print('========= cluster_0 =========')
        log = ''
        for i in range(0, len(cluster_0_idx), 20):
            print(cluster_0_idx[i:i + 20])
        print('========= cluster_1 =========')
        for i in range(0, len(cluster_1_idx), 20):
            print(cluster_1_idx[i:i + 20])
        print('========= cluster_2 =========')
        for i in range(0, len(cluster_2_idx), 20):
            print(cluster_2_idx[i:i + 20])

        break
    loop_cnt += 1

print(f'lb_actual:{lb_actual}')
print(f'lb_cluster:{lb_cluster}')
# for i in range(len(lb_actual)):
#     print(f'i: {i}   actual_label: {lb_actual[i]}   predicted_label: {lb_cluster[i]}')


''' Clustering Measurement '''

def cal_NMI(X, Y):       # X:cluster_label    Y:actual_label
    #样本点数
    lb_X = set(X)
    lb_Y = set(Y)
    total_num = len(X)
    #互信息计算
    MI = 0
    eps = 1.4e-45           # 最小float值 避免出现log0
    for item_X in lb_X:
        for item_Y in lb_Y:
            lb_X_num = X.count(item_X)
            lb_Y_num = Y.count(item_Y)
            lb_XY_num = 0
            for i in range(total_num):
                if X[i] == item_X and Y[i] == item_Y:
                    lb_XY_num += 1
            px = 1.0 * lb_X_num / total_num
            py = 1.0 * lb_Y_num / total_num
            pxy = 1.0 * lb_XY_num / total_num

            MI = MI + pxy * math.log(pxy / (px * py) + eps, 2)


    Hx = 0
    for item_X in lb_X:
        lb_X_num = X.count(item_X)
        Hx = Hx - (lb_X_num / total_num) * math.log(lb_X_num / total_num + eps, 2)
    Hy = 0
    for item_Y in lb_Y:
        lb_Y_num = Y.count(item_Y)
        Hy = Hy - (lb_Y_num / total_num) * math.log(lb_Y_num / total_num + eps, 2)

    NMI = MI / ((Hx + Hy) / 2)
    return NMI

print(f'\nNMI: {cal_NMI(lb_cluster, lb_actual)}')

A = np.array(lb_cluster)
B = np.array(lb_actual)

print(f'NMI_normalized: {metrics.normalized_mutual_info_score(A, B)}')



''' Visualization of Results '''

''' 原始数据 '''
fig, axes = plt.subplots(2, 3, figsize=(15, 9))


color = 'darkgray'
axes[0][0].scatter(feature_original[0], feature_original[1], c=color)
axes[0][0].set_xlabel('Sepal.Length')
axes[0][0].set_ylabel('Sepal.Width')
# axes[0][0].set_title(' ')

axes[0][1].scatter(feature_original[0], feature_original[2], c=color)
axes[0][1].set_xlabel('Sepal.Length')
axes[0][1].set_ylabel('Petal.Length')

axes[0][2].scatter(feature_original[0], feature_original[3], c=color)
axes[0][2].set_xlabel('Sepal.Length')
axes[0][2].set_ylabel('Petal.Width')

axes[1][0].scatter(feature_original[1], feature_original[2], c=color)
axes[1][0].set_xlabel('Sepal.Width')
axes[1][0].set_ylabel('Petal.Length')

axes[1][1].scatter(feature_original[1], feature_original[3], c=color)
axes[1][1].set_xlabel('Sepal.Width')
axes[1][1].set_ylabel('Petal.Width')

axes[1][2].scatter(feature_original[2], feature_original[3], c=color)
axes[1][2].set_xlabel('Petal.Length')
axes[1][2].set_ylabel('Petal.Width')



'''完成聚类后数据'''
fig1, axes = plt.subplots(2, 3, figsize=(15, 9))

center_size = 350
axes[0][0].scatter(c0_feature[0], c0_feature[1])
axes[0][0].scatter(c1_feature[0], c1_feature[1])
axes[0][0].scatter(c2_feature[0], c2_feature[1])
axes[0][0].scatter(cluster_center[0][0], cluster_center[0][1], marker='+', s=center_size)
axes[0][0].scatter(cluster_center[1][0], cluster_center[1][1], marker='+', s=center_size)
axes[0][0].scatter(cluster_center[2][0], cluster_center[2][1], marker='+', s=center_size)
axes[0][0].set_xlabel('Sepal.Length')
axes[0][0].set_ylabel('Sepal.Width')
# axes[0][0].set_title(' ')

axes[0][1].scatter(c0_feature[0], c0_feature[2])
axes[0][1].scatter(c1_feature[0], c1_feature[2])
axes[0][1].scatter(c2_feature[0], c2_feature[2])
axes[0][1].scatter(cluster_center[0][0], cluster_center[0][2], marker='+', s=center_size)
axes[0][1].scatter(cluster_center[1][0], cluster_center[1][2], marker='+', s=center_size)
axes[0][1].scatter(cluster_center[2][0], cluster_center[2][2], marker='+', s=center_size)
axes[0][1].set_xlabel('Sepal.Length')
axes[0][1].set_ylabel('Petal.Length')

axes[0][2].scatter(c0_feature[0], c0_feature[3])
axes[0][2].scatter(c1_feature[0], c1_feature[3])
axes[0][2].scatter(c2_feature[0], c2_feature[3])
axes[0][2].scatter(cluster_center[0][0], cluster_center[0][3], marker='+', s=center_size)
axes[0][2].scatter(cluster_center[1][0], cluster_center[1][3], marker='+', s=center_size)
axes[0][2].scatter(cluster_center[2][0], cluster_center[2][3], marker='+', s=center_size)
axes[0][2].set_xlabel('Sepal.Length')
axes[0][2].set_ylabel('Petal.Width')

axes[1][0].scatter(c0_feature[1], c0_feature[2])
axes[1][0].scatter(c1_feature[1], c1_feature[2])
axes[1][0].scatter(c2_feature[1], c2_feature[2])
axes[1][0].scatter(cluster_center[0][1], cluster_center[0][2], marker='+', s=center_size)
axes[1][0].scatter(cluster_center[1][1], cluster_center[1][2], marker='+', s=center_size)
axes[1][0].scatter(cluster_center[2][1], cluster_center[2][2], marker='+', s=center_size)
axes[1][0].set_xlabel('Sepal.Width')
axes[1][0].set_ylabel('Petal.Length')

axes[1][1].scatter(c0_feature[1], c0_feature[3])
axes[1][1].scatter(c1_feature[1], c1_feature[3])
axes[1][1].scatter(c2_feature[1], c2_feature[3])
axes[1][1].scatter(cluster_center[0][1], cluster_center[0][3], marker='+', s=center_size)
axes[1][1].scatter(cluster_center[1][1], cluster_center[1][3], marker='+', s=center_size)
axes[1][1].scatter(cluster_center[2][1], cluster_center[2][3], marker='+', s=center_size)
axes[1][1].set_xlabel('Sepal.Width')
axes[1][1].set_ylabel('Petal.Width')

axes[1][2].scatter(c0_feature[2], c0_feature[3])
axes[1][2].scatter(c1_feature[2], c1_feature[3])
axes[1][2].scatter(c2_feature[2], c2_feature[3])
axes[1][2].scatter(cluster_center[0][2], cluster_center[0][3], marker='+', s=center_size)
axes[1][2].scatter(cluster_center[1][2], cluster_center[1][3], marker='+', s=center_size)
axes[1][2].scatter(cluster_center[2][2], cluster_center[2][3], marker='+', s=center_size)
axes[1][2].set_xlabel('Petal.Length')
axes[1][2].set_ylabel('Petal.Width')

# 自动调整子图之间的距离
plt.tight_layout()

# 显示图形
plt.show()



