d = {}
for i in range(0,12):
    d[i] = i
print(d)
cnt = 0
for i in d:
    print(f'{i}:{d[i]},', end='')
    cnt += 1
    if cnt % 5 == 0 and cnt != 0:
        print()
l = [1.111, 2.222, 3.333]
print(l)
# def round_list(lst):
#     return [round(num, 1) for num in lst]
# # print(round_list(l))
# print([round(num, 2) for num in l])
# l = [round(num, 2) for num in l]
# print(l)
import decimal
a = decimal.Decimal('350')
b = decimal.Decimal('1.4')




