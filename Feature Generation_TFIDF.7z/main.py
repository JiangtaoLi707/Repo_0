from nltk . stem . porter import *
from collections import Counter
import numpy as np
import re
import os
import math
import time

start = time.time()
main_folder_path = "F:\Assignment_1_fyh\dataset-temp\documents-export-2023-10-23\dataset\\alt.atheism"         # 文档路径

non_alpha_letters = re.compile(r'[^a-zA-Z]+')      # 以非字母的字符去分割
stopwords = set()
with open("F:\Assignment_1_fyh\dataset-temp\documents-export-2023-10-23\stopwords.txt", "r", encoding="Latin1") as f:
    l_stopwords = f.readlines()
    # print(l_stopwords)
    for i in l_stopwords:
        stopwords.add(i.strip('\n'))    # 用set去容纳所有的stopwords


WordSet_alldoc = []    # all words (N*1)
DocSet = []            # all words (N*D)   # 遍历了每一篇文章，把每一篇文章都进行文本处理，得到一个字典  {A:5  B:4   C:3....}

for root, dirs, files in os.walk(main_folder_path):    # 遍历文件夹中所有文件  
    # print(files)
    for file_name in files:
        WordSet_singledoc = []     # all words (n*1)   # 对每一篇文章都新建一个列表，用来存出现的词，和其各自出现的次数
        file_path = os.path.join(root, file_name)     #获取当前这篇文章的存储路径
        # print(file_path)
        with open(file_path, "r", encoding="Latin1") as f:   # 打开这篇文档！
            content = f.readlines()                          # 读取文档里面的内容，内容存到content里
            for i in content:                    #  这里 i 是原文里每一行的内容，不做任何处理，包含各种字符、空格
                for item in non_alpha_letters.split(i):     # item指的是划分完之后具体的单词，non_alpha_letters.split(i)为了划分词
                    if item.lower() not in stopwords and item != '':
                        item = re.sub(r'[^a-z]', '', item.lower()).strip()     # 只保留字母、转成小写     “   cab  ”-> "cab"
                        # dataset_all.append(re.sub(r'[^a-z]', '', item.lower()).strip())
                        WordSet_singledoc.append(item)     # 放进当前这篇文档对应的列表里   【A,B,B,A,C,GF,SDF,ASD,ASD】
                        # WordSet_alldoc.append(item)        # 放进所有文章对应的词汇表里面
            stemmer = PorterStemmer()
            WordSet_singledoc = [stemmer.stem(word) for word in WordSet_singledoc]    #去除词的后缀，找词根

            WordSet_alldoc += WordSet_singledoc     #
            d_wordcnt_singledoc = {}    # 新建字典，对应当前这篇文章，为了后续进行词频处理

            word_counts = Counter(WordSet_singledoc)     # 词频计数
            for word, count in word_counts.items():
                d_wordcnt_singledoc[word] = count            # 写入字典
            DocSet.append(d_wordcnt_singledoc)          # d_wordcnt_singledoc = {'A':5, 'B':10, ...}


d_wordcnt_alldoc = {}
word_counts = Counter(WordSet_alldoc)
for word, count in word_counts.items():
    d_wordcnt_alldoc[word] = count        #生成一个总的字典，把所有文章里出现的词和各自出现的次数都统计出来

N = len(DocSet)             # 数据集里总共有N篇文章
D = len(d_wordcnt_alldoc)   # 所有文章里出现的词的个数，一共有D个词

WordSet_final = list(d_wordcnt_alldoc)    # 把所有文章里出现的词都放进一个列表里
WordSet_final.sort()    #根据首字母对词汇做排序

d_final = {}
for i in WordSet_final:
    d_final[i] = 0

def cal_aik(k, N, d_wordcnt_singledoc, DocSet):
    d_wordcnt_singledoc.values()
    total_words_num = sum(d_wordcnt_singledoc.values())   #统计当前这篇文章里一共有多少词数，包含重复词
    if k not in d_wordcnt_singledoc:
        return 0

    TF = d_wordcnt_singledoc[k] / total_words_num      # f_ik

    nk = 0   # 所有文档里，出现过词汇k的文档数目
    for i in DocSet:
        if k in i:
            nk += 1
    if nk != 0:
        IDF = math.log((N / nk), 10)
    elif nk == 0:
        IDF = math.log((N / (nk+1)), 10)

    a_ik = TF * IDF
    return a_ik

def sortedDictValues(adict):   # 对字典排序，寻找出现次数前几名的word
    items = list(adict.items())
    items.sort(key=lambda x:x[1], reverse=True)
    return [(key, value) for key, value in items]
import decimal
a = decimal.Decimal('350')
b = decimal.Decimal('1.4')
l_A = []
cnt = 0
for l_singledoc in DocSet:
    l_A_row_temp = []
    temp_val = 0
    for word in WordSet_final:      # 总词库里的每个词，在当前这篇文档里出现的次数
        a_ij = cal_aik(word, len(DocSet), l_singledoc, DocSet)
        temp_val += a_ij**2    #求平方
        vector = cal_aik(word, len(DocSet), l_singledoc, DocSet)
        l_A_row_temp.append(vector)
    temp_val = pow(temp_val, 0.5)   #开根号，算出来就是分母 对一篇文章来说，不论是针对哪个词，分母都是一样的
    l_A_row = list(np.array(l_A_row_temp) / temp_val)   # 先把分子都存进列表l_A_row_temp，等这篇文章所有词都遍历完，给每一个向量（分子）都除以分母temp_val
    t = 0
    for i in d_final:
        d_final[i] += l_A_row[t]
        t += 1
    cnt += 1
    print(cnt)

res = sortedDictValues(d_final)    # 分析出现次数最高的10个词
# print(res[:10])
l_res = res[:20]
cnt = 0
for i in l_res:
    print(i, end='')
    cnt += 1
    if cnt % 5 == 0 and cnt != 0:
        print()


A = np.array(l_A).T   # 转化为矩阵
np.savez('train-20ng.npz', X=A)   # 保存.npz文件

stop = time.time()     # 计算代码跑了多久
print(f"Running time:{(stop-start)/60}min")







